<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('AppLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $anchoCompleto = false; ?>
    <div class="div-ampliar mx-auto <?php echo e($anchoCompleto ? '' : 'max-w-7xl'); ?> px-2 sm:px-6 lg:px-8 py-8"
        wire:className="<?php echo e($anchoCompleto ? '' : 'max-w-7xl'); ?>">

        <div class="flex rounded-lg bg-azul-oscuro py-2 px-4 items-center justify-center space-x-2">

            <?php if(isset($previous_exercise)): ?>
                <a href="<?php echo e(route('exercises.show', $previous_exercise->id)); ?>"
                    class="inline-flex items-center bg-azul-oscuro hover:bg-azul-electrico text-white font-bold py-1 px-3 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-3" viewBox="0 0 20 20" fill="#ffffff">
                        <path fill-rule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L9.414 11H13a1 1 0 100-2H9.414l1.293-1.293z"
                            clip-rule="evenodd" />
                    </svg> Ejercicio Anterior
                </a>
            <?php endif; ?>

            <?php if(isset($next_exercise)): ?>
                <a href="<?php echo e(route('exercises.show', $next_exercise->id)); ?>"
                    class="inline-flex items-center bg-azul-oscuro hover:bg-azul-electrico text-white font-bold py-1 px-3 rounded-full">
                    Ejercicio Siguiente
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 ml-3" viewBox="0 0 20 20" fill="#ffffff">
                        <path fill-rule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z"
                            clip-rule="evenodd" />
                    </svg>
                </a>
            <?php endif; ?>

        </div>


        <div class="mb-4"></div>

        <div class="rounded-lg bg-azul-oscuro py-4 px-4 mb-4">
            <div class="flex justify-between">
                <div class="flex">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('expand-button', ['anchoCompleto' => $anchoCompleto])->html();
} elseif ($_instance->childHasBeenRendered('A2ujbsL')) {
    $componentId = $_instance->getRenderedChildComponentId('A2ujbsL');
    $componentTag = $_instance->getRenderedChildComponentTagName('A2ujbsL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('A2ujbsL');
} else {
    $response = \Livewire\Livewire::mount('expand-button', ['anchoCompleto' => $anchoCompleto]);
    $html = $response->html();
    $_instance->logRenderedChild('A2ujbsL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('video-button', [])->html();
} elseif ($_instance->childHasBeenRendered('K2cFQ6F')) {
    $componentId = $_instance->getRenderedChildComponentId('K2cFQ6F');
    $componentTag = $_instance->getRenderedChildComponentTagName('K2cFQ6F');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('K2cFQ6F');
} else {
    $response = \Livewire\Livewire::mount('video-button', []);
    $html = $response->html();
    $_instance->logRenderedChild('K2cFQ6F', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('like-button', ['exercise' => $exercise])->html();
} elseif ($_instance->childHasBeenRendered('AuZRcS6')) {
    $componentId = $_instance->getRenderedChildComponentId('AuZRcS6');
    $componentTag = $_instance->getRenderedChildComponentTagName('AuZRcS6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AuZRcS6');
} else {
    $response = \Livewire\Livewire::mount('like-button', ['exercise' => $exercise]);
    $html = $response->html();
    $_instance->logRenderedChild('AuZRcS6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('report-button', ['exercise' => $exercise])->html();
} elseif ($_instance->childHasBeenRendered('Q7mYbXK')) {
    $componentId = $_instance->getRenderedChildComponentId('Q7mYbXK');
    $componentTag = $_instance->getRenderedChildComponentTagName('Q7mYbXK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Q7mYbXK');
} else {
    $response = \Livewire\Livewire::mount('report-button', ['exercise' => $exercise]);
    $html = $response->html();
    $_instance->logRenderedChild('Q7mYbXK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('save-exercise-button', ['exercise' => $exercise])->html();
} elseif ($_instance->childHasBeenRendered('0UTmztv')) {
    $componentId = $_instance->getRenderedChildComponentId('0UTmztv');
    $componentTag = $_instance->getRenderedChildComponentTagName('0UTmztv');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0UTmztv');
} else {
    $response = \Livewire\Livewire::mount('save-exercise-button', ['exercise' => $exercise]);
    $html = $response->html();
    $_instance->logRenderedChild('0UTmztv', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>
                <div class="flex items-center">
                    <a href="<?php echo e(route('exercises.item', $exercise->item->id)); ?>"
                        class="flex items-center bg-azul-claro hover:bg-azul-muyclaro text-azul-oscuro font-bold py-1 px-3 rounded-full mr-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24"
                            stroke="#0F4069" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M12 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2M3 12l6.414 6.414a2 2 0 001.414.586H19a2 2 0 002-2V7a2 2 0 00-2-2h-8.172a2 2 0 00-1.414.586L3 12z" />
                        </svg>
                        <span>Volver</span>
                    </a>
                    <a href="<?php echo e(route('exercises.sector', $exercise->item->section->chapter->sector->id)); ?>"
                        class="flex items-center bg-azul-claro hover:bg-azul-muyclaro text-azul-oscuro font-bold py-1 px-3 rounded-full mr-4">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 " fill="none" viewBox="0 0 24 24"
                            stroke="#0F4069" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                        <span>Cerrar</span>
                    </a>
                </div>
            </div>

            <div class="flex flex-row justify-center items-center mt-4">

            </div>
            <div class="image-section h-14 rounded-lg w-400 h-300 flex items-center"
                style="background-image: url(<?php echo e(asset(Storage::url($background_cuadros->image_path ?? ''))); ?>)">
                <?php if(empty(!$header_exercise)): ?>
                    <img src="<?php echo e(asset(Storage::url($header_exercise->image_path))); ?>" alt="" class="ml-10">
                <?php endif; ?>
            </div>

            <div class="image-section h-6 rounded-lg w-400 h-300 flex items-center bg-azul-muyclaro py-1 mt-1">
                <svg xmlns="http://www.w3.org/2000/svg" class="ml-4 h-5 w-5" viewBox="0 0 20 20" fill="#0F4069">
                    <path fill-rule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z"
                        clip-rule="evenodd" />
                </svg><span class="ml-4 font-bold italic text-azul-oscuro">Desarrollo</span>
            </div>

            <?php $__currentLoopData = $development_exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $development_exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="image-section rounded-lg w-400 h-300 flex items-center mt-1"
                    style="background-image: url(<?php echo e(asset(Storage::url($background_cuaderno->image_path ?? ''))); ?>)">
                    <?php if(!empty($development_exercise)): ?>
                        <img src="<?php echo e(asset(Storage::url($development_exercise->image_path))); ?>" alt=""
                            class="ml-12">
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <?php if(Auth::check()): ?>
            <form method="POST" action="<?php echo e(route('exercise.comments_store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="exercise_id" value="<?php echo e($exercise->id); ?>">
                <div class="flex flex-col mb-4">
                    <label for="comment_content" class="mb-2 font-bold text-azul-oscuro text-xs">Agrega un
                        comentario:</label>
                    <textarea name="comment_content" id="comment_content" rows="1"
                        class="text-xs px-3 py-2 bg-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"></textarea>
                </div>
                <button type="submit"
                    class="text-xs flex items-center bg-azul-semi hover:bg-azul-electrico text-white font-bold py-1 px-3 rounded-full mr-4">Comentar</button>
            </form>
        <?php endif; ?>

        <?php if($exercise->exercise_comments): ?>

            <div class="mt-8">
                <?php $__currentLoopData = $exercise->exercise_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-start mb-4">
                        <div class="mr-2"> <img src="<?php echo e(asset(Storage::url($comment->user->profile_photo_path))); ?>"
                                alt="Foto de perfil de <?php echo e($comment->user->name); ?>" class="w-6 h-6 rounded-full"> </div>
                        <div class="flex-1">
                            <div class="flex items-center mb-1">
                                <p class="mr-2 font-bold text-xs text-azul-oscuro"><?php echo e($comment->user->name); ?></p>
                                <p class="text-xs text-gray-500"><?php echo e($comment->created_at->diffForHumans()); ?></p>
                            </div>
                            <p class="text-gray-900 text-xs"><?php echo e($comment->comment_content); ?></p>
                            <form method="POST" action="<?php echo e(route('exercise.comments_store')); ?>"> <?php echo csrf_field(); ?> <input
                                    type="hidden" name="parent_id" value="<?php echo e($comment->id); ?>">
                                <textarea name="comment_content" rows="3" class="form-control"></textarea> <button class="btn btn-primary mt-3">Responder</button>
                            </form> <?php if(auth()->guard()->check()): ?> <?php if($comment->user_id == Auth::user()->id): ?>
                                <form action="<?php echo e(route('exercise.comments_destroy', $comment->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> <button type="submit"
                                        class="text-xs text-red-500 hover:text-red-700 focus:outline-none"> Eliminar
                                        comentario </button> </form>
                            <?php endif; ?> <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\gm23\resources\views/exercises/show.blade.php ENDPATH**/ ?>