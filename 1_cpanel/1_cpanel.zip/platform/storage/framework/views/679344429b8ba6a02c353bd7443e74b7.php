<div <?php echo e($attributes->class(['filament-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\gm23\vendor\filament\support\src\/../resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>