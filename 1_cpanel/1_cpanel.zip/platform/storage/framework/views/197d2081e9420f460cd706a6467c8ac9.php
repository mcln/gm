
<?php /**PATH C:\xampp\htdocs\gm23\vendor\filament\filament\src\/../resources/views/components/layouts/app/sidebar/footer.blade.php ENDPATH**/ ?>