<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('AppLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="div-ampliar mx-auto max-w-7xl px-2 sm:px-6 lg:px-8 py-8">  

        <div class="flex rounded-lg bg-azul-oscuro py-2 px-4 items-center">
            <a href="<?php echo e(route('exercises.sector', $sections->first()->chapter->sector->id)); ?>" class="inline-flex items-center bg-azul-oscuro hover:bg-azul-electrico text-white font-bold py-1 px-3 rounded-full">
                <?php echo e(ucfirst($sections->first()->chapter->sector->name)); ?>

            </a>
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 inline-block mx-2" fill="none" viewBox="0 0 24 24" stroke="#ffffff" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M13 5l7 7-7 7M5 5l7 7-7 7" />
            </svg>
            <div class="inline-flex items-center bg-red-700 text-white font-bold py-1 px-3 rounded-full">                                                                                                                           
                <?php echo e(ucfirst($sections->first()->chapter->name)); ?>

            </div>
        </div>
        <div class="mb-4"></div>
        <div class="rounded-lg grid grid-cols-1 gap-1 py-4 px-4 bg-azul-oscuro">
            <?php $i = 1 ?>
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('exercises.section', ['section' => $section->id])); ?>" class="bg-white hover:bg-azul-claro rounded-lg">
                    <span class="hover:text-white text-sm font-medium text-gray-900 pl-4"><?php echo e($i++); ?>. </span>
                    <span class="text-sm font-medium text-gray-900"><?php echo e(ucfirst($section->name)); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\gm23\resources\views/exercises/chapter.blade.php ENDPATH**/ ?>