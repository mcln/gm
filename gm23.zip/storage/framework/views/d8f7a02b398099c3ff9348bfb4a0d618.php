<h1 <?php echo e($attributes->class(['filament-header-heading text-2xl font-bold tracking-tight'])); ?>>
    <?php echo e($slot); ?>

</h1>
<?php /**PATH C:\xampp\htdocs\gm23\vendor\filament\filament\src\/../resources/views/components/header/heading.blade.php ENDPATH**/ ?>