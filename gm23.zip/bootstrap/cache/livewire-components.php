<?php return array (
  'edit-directory-button' => 'App\\Http\\Livewire\\EditDirectoryButton',
  'exercise-user' => 'App\\Http\\Livewire\\ExerciseUser',
  'expand-button' => 'App\\Http\\Livewire\\ExpandButton',
  'like-button' => 'App\\Http\\Livewire\\LikeButton',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
  'report-button' => 'App\\Http\\Livewire\\ReportButton',
  'save-exercise-button' => 'App\\Http\\Livewire\\SaveExerciseButton',
  'video-button' => 'App\\Http\\Livewire\\VideoButton',
);